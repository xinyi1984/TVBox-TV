package com.xunlei.downloadlib.parameter;

public class MagnetTaskParam {

    public String mFileName;
    public String mFilePath;
    public String mUrl;

    public void setUrl(String str) {
        this.mUrl = str;
    }

    public void setFileName(String str) {
        this.mFileName = str;
    }

    public void setFilePath(String str) {
        this.mFilePath = str;
    }
}
