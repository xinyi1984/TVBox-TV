package com.xunlei.downloadlib.parameter;

public class BtSubTaskDetail {

    public int mFileIndex;
    public boolean mIsSelect;
    public XLTaskInfo mTaskInfo = new XLTaskInfo();
}
