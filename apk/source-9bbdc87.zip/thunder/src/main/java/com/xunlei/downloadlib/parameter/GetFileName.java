package com.xunlei.downloadlib.parameter;

public class GetFileName {

    public String mFileName;

    public String getFileName() {
        return mFileName;
    }
}
