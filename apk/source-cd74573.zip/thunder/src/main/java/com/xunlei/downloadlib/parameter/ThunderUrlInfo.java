package com.xunlei.downloadlib.parameter;

public class ThunderUrlInfo {

    public String mUrl;
}
