package com.xunlei.downloadlib.parameter;

public class GetDownloadLibVersion {

    public String mVersion;
}
