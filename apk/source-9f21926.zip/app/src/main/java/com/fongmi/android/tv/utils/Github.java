package com.fongmi.android.tv.utils;

public class Github {
    
    public static final String URL = "https://ghfast.top/https://raw.githubusercontent.com/xinyi1984/TVBox-TV/fongmi";

    private static String getUrl(String name) {
        return URL + "/apk/" + name;
    }

    public static String getJson(String name) {
        return getUrl(name + ".json");
    }

    public static String getApk(String name) {
        return getUrl(name + ".apk");
    }
}
