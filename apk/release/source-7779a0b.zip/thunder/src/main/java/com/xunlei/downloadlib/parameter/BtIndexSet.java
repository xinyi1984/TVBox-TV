package com.xunlei.downloadlib.parameter;

public class BtIndexSet {

    public int[] mIndexSet;

    public BtIndexSet(int i) {
        this.mIndexSet = new int[i];
    }
}
