package com.fongmi.android.tv.impl;

import com.github.catvod.bean.Doh;

public interface DohCallback {

    void setDoh(Doh doh);
}
