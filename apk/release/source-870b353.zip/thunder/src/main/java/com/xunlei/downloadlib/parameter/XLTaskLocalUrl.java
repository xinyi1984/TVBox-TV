package com.xunlei.downloadlib.parameter;

public class XLTaskLocalUrl {

    public String mStrUrl;
}
