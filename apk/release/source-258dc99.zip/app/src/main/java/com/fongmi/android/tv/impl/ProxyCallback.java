package com.fongmi.android.tv.impl;

public interface ProxyCallback {

    void setProxy(String proxy);
}
