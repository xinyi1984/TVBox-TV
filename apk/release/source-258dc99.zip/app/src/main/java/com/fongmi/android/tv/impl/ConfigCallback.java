package com.fongmi.android.tv.impl;

import com.fongmi.android.tv.bean.Config;

public interface ConfigCallback {

    void setConfig(Config config);
}
