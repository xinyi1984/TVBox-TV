package com.gsoft.mitv;

import android.os.Binder;

public class LocalBinder extends Binder {
}
