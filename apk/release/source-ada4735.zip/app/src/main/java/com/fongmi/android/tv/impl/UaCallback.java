package com.fongmi.android.tv.impl;

public interface UaCallback {

    void setUa(String ua);
}
