package com.forcetech.service;

import com.forcetech.Util;

public class P3PService extends PxPService {

    @Override
    public int getPort() {
        return Util.P3P;
    }
}
