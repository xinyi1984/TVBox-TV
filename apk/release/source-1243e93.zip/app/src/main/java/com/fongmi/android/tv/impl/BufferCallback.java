package com.fongmi.android.tv.impl;

public interface BufferCallback {

    void setBuffer(int times);
}
