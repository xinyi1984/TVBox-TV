package com.fongmi.android.tv.impl;

import com.fongmi.android.tv.bean.Live;

public interface LiveCallback {

    void setLive(Live item);
}
